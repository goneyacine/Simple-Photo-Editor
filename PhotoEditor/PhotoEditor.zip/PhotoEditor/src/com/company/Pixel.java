package com.company;

public class Pixel {
    //the position of this pixel (x and y position)
    public int x;
    public int y;

    public Pixel(int x, int y){
        this.x = x;
        this.y = y;
    }

}
