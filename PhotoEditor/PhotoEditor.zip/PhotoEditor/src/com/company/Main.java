package com.company;

import java.awt.*;
import java.util.Scanner;

import com.RandomNoise;

import GUI.*;
public class Main {

    public static void main(String[] args) {
      StartWindow startWindow = new StartWindow();

    }
}
