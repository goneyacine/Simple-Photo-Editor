package interfaces;

public interface tool {
}
