package interfaces;

public interface selectTool extends tool {
    public void select();
}
